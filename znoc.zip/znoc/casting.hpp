/*#ifndef _CASTING_H
#define _CASTING_H

#include <llvm/IR/Value.h>
#include <llvm/IR/Type.h>
#include <llvm/IR/IRBuilder.h>

llvm::Value* create_cast(llvm::IRBuilder<> *builder, llvm::Value *src, llvm::Type *dest);

#endif*/