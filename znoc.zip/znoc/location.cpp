#include "location.hpp"

SourceLocation LexLoc = {1, 0};